package com.example.pichau.milhasemmetros2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class mnaPrincipal extends AppCompatActivity
{
    EditText edtMilhas;
    Button btnConverter;
    TextView txvResultado;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mna_principal);
        InicializarComponentes();
        Eventos();
    }

    public void InicializarComponentes()
    {
        edtMilhas = (EditText) findViewById(R.id.edtMilha);
        btnConverter = (Button) findViewById(R.id.btnConverter);
        txvResultado = (TextView) findViewById(R.id.txvResultado);

    }
    public void Eventos()
    {
        btnConverter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                Double n1=0.0, res = 0.0;
                n1=Double.parseDouble(edtMilhas.getText().toString());
                res = (n1 * 1609)/1000;
                txvResultado.setText(res.toString());
            }
        });

    }
}
