package com.example.pichau.calcularamdiaentreavaliaessefoiaprovadoreprovadoouexame;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class mnaPrincipal extends AppCompatActivity
{
    EditText edtNumero1;
    EditText edtNumero2;
    Button btnCalcular;
    TextView txvResultado;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mna_principal);
        InicializarComponentes();
        Eventos();
    }

    public void InicializarComponentes()
    {
        edtNumero1 = (EditText) findViewById(R.id.edtNumero1);
        edtNumero2 = (EditText) findViewById(R.id.edtNumero2);
        btnCalcular = (Button) findViewById(R.id.btnCalcular);
        txvResultado = (TextView) findViewById(R.id.txvResultado);
    }

    public void Eventos()
    {
        btnCalcular.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Double n1 = 0.0, n2 = 0.0, res = 0.0;
                n1=Double.parseDouble(edtNumero1.getText().toString());
                n2=Double.parseDouble(edtNumero2.getText().toString());
                res = (n1 + n2 )/ 2;
                if (res<4)
                {
                    txvResultado.setText(res.toString() + " Reprovado");
                }
                if (res>=7)
                {
                    txvResultado.setText(res.toString() + " Aprovado");
                }
                if (res<7 && res>4)
                {
                    txvResultado.setText(res.toString() + " Exame");
                }
            }
        });
    }
}
