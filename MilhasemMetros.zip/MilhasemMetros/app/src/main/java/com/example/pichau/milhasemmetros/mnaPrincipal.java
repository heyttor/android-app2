package com.example.pichau.milhasemmetros;

import android.content.Context;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class mnaPrincipal extends AppCompatActivity
{
    EditText edtNumero1;
    EditText edtNumero2;
    Button btnConverter;
    TextView txvRsultado;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mna_principal);
        InicializarComponentes();
        Eventos();
    }
    public void InicializarComponentes()
    {

        edtNumero1 = (EditText) findViewById(R.id.edtNumero1);
        edtNumero2 = (EditText) findViewById(R.id.edtNumero2);
        btnConverter = (Button) findViewById(R.id.btnConverter);
        txvRsultado = (TextView) findViewById(R.id.txvResultado);


    }

  public void Eventos()
  {
      btnConverter.setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View v)
          {
              Double n1 =0.0, n2 = 0.0, res = 0.0;
              n1 = Double.parseDouble(edtNumero1.getText().toString());
              n2 = Double.parseDouble(edtNumero2.getText().toString());
              res = n1 + n2;
              txvRsultado.setText(res.toString());

          //    Toast.makeText(getApplicationContext()),
        //              Text: "o resultado é " + res,
      //        Toast.LENGTH_SHORT).show();
             // AlertDialog alrta = new AlertDialog.Builder(Context: this)

          }
      });
  }
}
