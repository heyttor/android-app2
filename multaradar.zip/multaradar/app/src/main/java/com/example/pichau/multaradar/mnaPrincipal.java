package com.example.pichau.multaradar;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class mnaPrincipal extends AppCompatActivity
{
    EditText edtVelocidade;
    EditText edtLimite;
    Button btnCalcular;
    TextView txvResultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mna_principal);
        InicializarComponentes();
        Eventos();
    }

    public void InicializarComponentes()
    {
        edtVelocidade = (EditText) findViewById(R.id.edtVelocidade);
        edtLimite = (EditText) findViewById(R.id.edtLimite);
        btnCalcular = (Button) findViewById(R.id.btnCalcular);
        txvResultado = (TextView) findViewById(R.id.txvResultado);
    }

    public  void Eventos()
    {
        btnCalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                Double n1 = 0.0, n2 = 0.0, res = 0.0;
                n1 = Double.parseDouble(edtVelocidade.getText().toString());
                n2 = Double.parseDouble(edtLimite.getText().toString());
                if (n1<n2)
                {
                    txvResultado.setText("no multa");
                }
                    if (n1 > n2)
                    {
                        res = n2 + (n2 * 0.10);
                        if (n1 < res)
                        {
                            txvResultado.setText("Multa de R$100");
                        }
                        if (n1 > res)
                        {
                            txvResultado.setText("Multa de R$200");
                        }
                    }
            }
        });
    }
}
